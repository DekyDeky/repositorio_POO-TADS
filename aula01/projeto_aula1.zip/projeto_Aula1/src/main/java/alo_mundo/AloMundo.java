package alo_mundo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Aluno
 */
public class AloMundo {
    public static void main(String[] args) {
        System.out.println("Alo, Mundo!");
    }
}
