/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade_Aula1;

import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class testarRetangulo {
    public static void main(String[] args){
        
        //Instancia novo retângulo
        retangulo novoRetangulo = new retangulo();
        
        //Instancia novo scanner
        Scanner entrada = new Scanner(System.in);
        
        //Ler entradas do usuário
        System.out.print("Digite a base do retângulo: ");
        novoRetangulo.base = entrada.nextDouble();
        
        System.out.print("Digite a altura do retângulo: ");
        novoRetangulo.altura = entrada.nextDouble();
        
        novoRetangulo.imprimir();
        
    }
}
