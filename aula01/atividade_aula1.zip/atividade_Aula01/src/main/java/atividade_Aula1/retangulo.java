/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade_Aula1;

/**
 *
 * @author Aluno
 */
public class retangulo {
    // Atributos
    double base;
    double altura;
    
    // Métodos
    void mostrarArea(){
        double area = base * altura;
        System.out.println("A área do retângulo é: " + area);
    }
    
    void mostrarPerimetro() {
        double perimetro = (2 * base) + (2 * altura);
        System.out.println("O perímetro do retângulo é: " + perimetro);
    }
    
    void imprimir() {
        System.out.println("A base é: " + base);
        System.out.println("A altura é: " + altura);
        mostrarArea();
        mostrarPerimetro();
    }
}
